-- phpMyAdmin SQL Dump
-- version 3.4.10.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 09, 2013 at 02:03 AM
-- Server version: 5.5.20
-- PHP Version: 5.3.10

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `symfony`
--

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE IF NOT EXISTS `blog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `author` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `author_email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `keywords` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `important` tinyint(1) DEFAULT NULL,
  `is_open` tinyint(1) DEFAULT NULL,
  `link` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `classify_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_C01551436B934342` (`classify_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=24 ;

--
-- Dumping data for table `blog`
--

INSERT INTO `blog` (`id`, `title`, `author`, `author_email`, `keywords`, `important`, `is_open`, `link`, `description`, `content`, `created`, `classify_id`) VALUES
(2, '男篮亚锦赛', '胡彬', 'fadsa@1.xosm', '男篮', 1, 1, 'http://http:/sdas', '发的萨芬', '佛挡杀佛', '2013-08-08 11:01:36', 2),
(3, '男篮亚锦赛', '神的', 'dsadsa@1.com', 'dsdas', 1, 1, 'http://http:/sdas', '倒萨', '倒萨', '2013-08-08 11:01:45', 2),
(6, '男篮亚锦赛', 'dsdads', 'as@ada.com', '神的', 0, 0, 'http://http:/sdas', '佛挡杀佛', '佛挡杀佛', '2013-08-08 23:50:18', 3),
(7, '维尔瓦', '神的', 'dsadsa@1.com', 'dsdas', 1, 1, 'http://fdsdfs', 'asdfasdf', 'asdfsa', '2013-08-09 01:15:27', 2),
(8, '男篮亚锦赛', '432', 'as@ada.com', 'dd', 1, 1, 'http://http:/sdas', 'gdg', 'fds', '2013-08-08 08:40:02', 2),
(9, '男篮亚锦赛', '胡彬', 'fadsa@1.xosm', '男篮', 1, 1, 'http://http:/sdas', '发的萨芬', '佛挡杀佛', '2013-08-08 08:40:50', 2),
(11, '男篮亚锦赛', 'dsdads', 'as@ada.com', '神的', 0, 1, 'http://http:/sdas', '佛挡杀佛', '佛挡杀佛', '2013-08-08 08:43:32', 2),
(12, '男篮亚锦赛', '胡彬', 'fadsa@1.xosm', '男篮', 1, 1, 'http://http:/sdas', '发的萨芬', '佛挡杀佛', '2013-08-08 08:45:46', 2),
(13, '男篮亚锦赛', '胡彬', 'fadsa@1.xosm', '男篮', 1, 1, 'http://http:/sdas', '发的萨芬', '佛挡杀佛', '2013-08-08 08:48:12', 2),
(19, '男篮亚锦赛', '胡彬', 'fadsa@1.xosm', '男篮', 0, 1, 'http://http:/sdas', '发的萨芬', '佛挡杀佛', '2013-08-08 09:18:25', 2),
(20, '男篮亚锦赛', '胡彬', 'fadsa@1.xosm', '男篮', 1, 1, 'http://http:/sdas', '发的萨芬', '佛挡杀佛', '2013-08-09 01:15:41', 2),
(21, '男篮亚锦赛', '胡彬', 'fadsa@1.xosm', '男篮', 1, 1, 'http://http:/sdas', '发的萨芬', '佛挡杀佛', '2013-08-08 09:29:08', NULL),
(22, '男篮亚锦赛', '胡彬', 'fadsa@1.xosm', '男篮', 1, 1, 'http://http:/sdas', '发的萨芬', '佛挡杀佛', '2013-08-08 09:29:16', NULL),
(23, '男篮亚锦赛', '胡彬', 'fadsa@1.xosm', '男篮', 1, 1, 'http://http:/sdas', '发的萨芬', '佛挡杀佛', '2013-08-08 09:29:22', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `classify`
--

CREATE TABLE IF NOT EXISTS `classify` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `classify` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `f_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `classify`
--

INSERT INTO `classify` (`id`, `classify`, `f_id`) VALUES
(1, '说明文章', 0),
(2, '网站公告', 0),
(3, '网站新闻', 0);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `blog`
--
ALTER TABLE `blog`
  ADD CONSTRAINT `FK_C01551436B934342` FOREIGN KEY (`classify_id`) REFERENCES `classify` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
